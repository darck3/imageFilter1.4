# filters.R

#' Grayscale Filter
#'
#' Converts a color pixel to grayscale using luminance calculation.
#'
#' @param rgb_vec A vector of 3 raw RGB values.
#' @return A vector of 3 identical raw values representing grayscale.
#' @export
greyscale_filter <- function(rgb_vec) {
  grey_val <- as.raw(round(
    0.299 * as.integer(rgb_vec[1]) +
      0.587 * as.integer(rgb_vec[2]) +
      0.114 * as.integer(rgb_vec[3])
  ))
  rep(grey_val, 3)
}

#' Cutoff Filter
#'
#' Applies a binary threshold to convert pixel to black or magenta.
#'
#' @param rgb_vec A vector of 3 raw RGB values.
#' @param cutoff A numeric threshold between 0 and 255.
#' @return A raw vector representing the new RGB value.
#' @export
cutoff_filter <- function(rgb_vec, cutoff = 127) {
  grey_val <- 0.299 * as.integer(rgb_vec[1]) +
    0.587 * as.integer(rgb_vec[2]) +
    0.114 * as.integer(rgb_vec[3])
  if (grey_val < cutoff) {
    as.raw(c(0, 0, 0))  # black
  } else {
    as.raw(c(255, 0, 255))  # magenta
  }
}

#' Apply a Filter to an Image Bitmap
#'
#' Applies a pixel-level filter function to each pixel in the bitmap.
#'
#' @param bitmap A bitmap matrix extracted from a magick image.
#' @param filter_func The filter function to apply (e.g., greyscale_filter).
#' @param ... Additional arguments passed to the filter function.
#'
#' @return A magick image object with the filter applied.
#' @export
apply_filter <- function(bitmap, filter_func, ...) {
  dims <- dim(bitmap)
  new_bitmap <- bitmap

  for (x in 1:dims[2]) {
    for (y in 1:dims[3]) {
      rgb_vec <- bitmap[, x, y]
      new_bitmap[, x, y] <- filter_func(rgb_vec, ...)
    }
  }

  magick::image_read(new_bitmap)
}
