test_that("greyscale_filter returns correct format", {
  result <- greyscale_filter(as.raw(c(100, 150, 200)))
  expect_equal(length(result), 3)
  expect_true(all(result == result[1]))
})
